%--------------------------------------------------------------------------------
% Validation data is found in a spreadsheet on this website:
% - http://www.rimworld.com/nassarocketry/fabrication/nosecones/spreadsheet.html 
%
% The direct link for the spreadsheet is here:
% - http://www.rimworld.com/nassarocketry/downloads/nosecones.xls
%--------------------------------------------------------------------------------

