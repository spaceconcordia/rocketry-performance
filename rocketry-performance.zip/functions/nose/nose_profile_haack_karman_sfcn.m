[theta, y, msg] = nose_profile_haack_karman_sfcn(x, L, R, C)
    [theta, y, msg] = nose_profile_haack(x, L, R, C)
