function R_crit = CRITREN(R_s, L)
%#codegen

R_crit=51*(R_s/L)^(-1.039);
end
