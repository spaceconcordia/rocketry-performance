function c = sound_speed(gamma, R, T)
 c = sqrt(gamma*R*T)