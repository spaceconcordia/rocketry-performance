function M = mach_number(v,c)

% v = velocity through the air
% c = sound speed
