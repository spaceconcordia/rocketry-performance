function cg = cg_calculate(rocket_mass, motor_mass_dry, motor_mass_wet, motor_mass_delta)

% As fuel is exausted, the center of gravity shifts
% This model computes the center of gravity of the rocket during flight
