function A_wet_fin = AWF(A_face_fin, A_front_fin)
%#codegen
A_wet_fin=2*A_face_fin+A_front_fin
end
