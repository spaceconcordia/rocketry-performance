function blkStruct = slblocks
    Browser.Library = 'rocket_dynamic_data_library';
    Browser.Name = 'Rocket Dynamic Data Library';
    blkStruct.Browser = Browser;
