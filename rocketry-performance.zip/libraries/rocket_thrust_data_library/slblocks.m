function blkStruct = slblocks
    Browser.Library = 'rocket_thrust_data_library';
    Browser.Name = 'Rocket Thrust Data Library';
    blkStruct.Browser = Browser;
