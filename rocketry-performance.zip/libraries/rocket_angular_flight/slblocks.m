function blkStruct = slblocks
    Browser.Library = 'rocket_angular_flight_library';
    Browser.Name = 'Rocket Angular Flight Library';
    blkStruct.Browser = Browser;
