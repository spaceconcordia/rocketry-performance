function blkStruct = slblocks
    Browser.Library = 'rocket_isa_model_library';
    Browser.Name = 'Rocket ISA Model Library';
    blkStruct.Browser = Browser;
