function blkStruct = slblocks
    Browser.Library = 'rocket_drag_library';
    Browser.Name = 'Rocket Drag Library';
    blkStruct.Browser = Browser;
