function blkStruct = slblocks
    Browser.Library = 'rocket_vertical_flight_library';
    Browser.Name = 'Rocket Vertical Flight Library';
    blkStruct.Browser = Browser;
