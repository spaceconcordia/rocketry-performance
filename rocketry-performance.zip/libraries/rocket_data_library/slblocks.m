function blkStruct = slblocks
    Browser.Library = 'rocket_data_library';
    Browser.Name = 'Rocket Data Library';
    blkStruct.Browser = Browser;
