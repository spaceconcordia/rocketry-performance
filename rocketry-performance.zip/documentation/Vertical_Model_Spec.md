# Vertical Model Specification

## Velocity and  
