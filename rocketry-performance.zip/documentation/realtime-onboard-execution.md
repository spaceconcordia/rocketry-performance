# Real-Time Onboard Simulation

## Introduction
We would like to run the performance model during flight to estimate the landing region

## Scope
This is officially out of the scope of the capstone project, but is a nice-to-have enhancement

## References
http://www.mathworks.com/products/simulink-real-time/

