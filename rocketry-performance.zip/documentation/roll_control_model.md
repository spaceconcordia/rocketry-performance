## Project 3 - Onboard Execution (Extra)

Run the simulation on the commercial avionics hardware and actuate the recovery system.
