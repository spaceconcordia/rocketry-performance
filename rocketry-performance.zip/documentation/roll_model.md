## Project 4 - Roll Control Model

## Spin Stabilization

- roll rate should have positive slope when crossing pitch frequency
[rocket-aero.pdf](https://explorersposts.grc.nasa.gov/post630/07-08%20Files/DocumentArchive/rocket%20aero.pdf)

## Active Stability Control

### Thrust Control System

TODO

### Servo-fins

TODO

### Side Thrusters

TODO
