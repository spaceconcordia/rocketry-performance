# References

[1] Simon Box, Christopher M. Bishop, and Hugh Hunt, Estimating the dynamic and aerodynamic parameters of passively controlled high power rockets for flight simulaton (February 2009), Available Online: http://cambridgerocket.sourceforge.net/AerodynamicCoefficients.pdf (Accessed October 1st, 2015)
