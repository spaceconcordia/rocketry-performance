# Meeting Minutes 

- 2015-09-27

## Teamwork Project Management System

- explore the features
- enable notifications

## Risk Assessment 

- Payload components are needed before moving forward with design

## 

## Statistical Analysis

- Need to finish analysis of last year's data to eliminate any sources of error and to drive Avionics decisions
- Need to find reliable sources of 3rd party data to validate our simulations
- Need to provide confidence limits of our simulations


