# Documentation Conventions

## Markdown 

## Pandoc

## LaTeX

### Equations
[LaTeX equations in Markdown+Pandoc]:(https://github.com/tomduck/pandoc-eqnos)
[StackOverflow - LaTeX equations in Markdown+Pandoc]:(http://stackoverflow.com/questions/25042901/how-to-use-latex-equation-environment-in-pandoc-markdown)

### Figures
[Figures in Markdown+Pandoc]:(http://stackoverflow.com/questions/9434536/how-do-i-make-a-reference-to-a-figure-in-markdown-using-pandoc)

## Look into
http://rmarkdown.rstudio.com/
