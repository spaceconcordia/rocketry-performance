# Moment of Inertia

##  
